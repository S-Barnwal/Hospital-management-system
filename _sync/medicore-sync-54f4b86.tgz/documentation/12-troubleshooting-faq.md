# 12. Troubleshooting & FAQ

## Common errors and fixes

| What you see | What it means | Fix |
|--------------|---------------|-----|
| `Failed to resolve import "react-toastify"` (or any other package) in the browser | A library is missing in `frontend` | In `frontend` run `npm install`, then `npm run dev` again |
| `Cannot find package 'express'` (or similar) in the backend terminal | Backend libraries not installed | In `backend` run `npm install` |
| `Failed to connect to <server>:1433 in 30000ms` | The backend can't reach the database | Check internet; check `DB_CONNECTION_STRING`; make sure the database host allows remote connections from your IP (many hosts need your IP added in their control panel); try again — the server retries 3 times |
| `Login failed for user …` | Wrong database user/password | Fix the values in `DB_CONNECTION_STRING` |
| `Tables not found. Run: npm run db:migrate …` / `Invalid object name 'hms.…'` | Database tables are not created or not up to date | `npm run db:migrate` then `npm run db:seed` |
| `Migration 00X failed: …` | One SQL script stopped (it is rolled back automatically) | Read the message; fix the cause (often permissions or an old SQL Server version); run `npm run db:migrate` again |
| `! 00X_….sql was modified after being applied` | An already-applied SQL script was edited | Never edit applied scripts; restore the original file and put changes in a new numbered script |
| Red pop-up *"Server error: …"* (development) | The backend hit a problem | Read the backend terminal — it prints the real reason |
| `401` / you are sent back to login | Session expired or wrong login page | Log in again. Hospital users use `/login`; the Super Admin uses `/admin/login` |
| *"Invalid e-mail or password"* for the demo hospital | Demo data not created | `npm run db:seed:demo` (local/test only) |
| Menu item shows **Upgrade** | The module is not in your plan | Subscription → change plan |
| *"Your role does not include access…"* or a menu item is missing | Your role lacks the permission | Ask the owner/admin to adjust your role; after a software update the admin should run `npm run db:seed` |
| *"Subscription expired… read-only"* | Plan end date + grace days passed | Owner → Subscription → Renew |
| *"This record is used elsewhere, so it cannot be deleted"* | It has history (e.g. a test that was ordered) | Mark it **inactive** instead — history must stay correct |
| *"… is included twice"* when placing a lab order | A test is selected individually and inside a package | Untick the individual test |
| *"Payments can only be recorded against a finalised bill"* | The bill is still a draft | Finalise the bill first |
| *"We could not send your sign-in code"* | 2-step sign-in is on but e-mail sending failed | Fix SMTP ([chapter 15](15-messaging-setup.md)); in an emergency turn the setting off directly in the database or ask the platform admin |
| Message log shows **logged** instead of **sent** | Messaging is in test mode | Configure `EMAIL_PROVIDER` / `WHATSAPP_PROVIDER` ([chapter 15](15-messaging-setup.md)) |
| *"Only verified reports can be sent to the patient"* | Report not verified yet | Verify the order first |
| Port `5000` or `5173` already in use | Another copy is already running | Close the other terminal, or restart the computer |

| TV screen shows numbers but is silent | Browsers only play sound after a tap | Tap the gold bar *“Tap here once to turn on announcements”* (or the speaker icon) once after opening the screen |
| TV screen says *“This screen link is no longer valid”* | The screen was removed, or the hospital is suspended | Token queue → TV display screens → *Add screen* and open the new link |
| A doctor is missing on the online booking page | Only active doctors with a weekly schedule are listed | Doctors & staff → the doctor → set the weekly schedule |
| Online booking page says *not available* | Booking is switched off | Settings → Online booking → tick and Save |
| *“This coupon …”* when applying a code | Expired, used up, not for this plan/billing/stage, or already used by your hospital | Check the code's rules with the provider; the message says which rule failed |
| *“A free trial has already been used …”* | One trial per e-mail and phone number | Choose *Buy now*, or sign in to the earlier workspace |

## FAQ

**Can two hospitals see each other's data?**
No. See [chapter 10](10-security-and-privacy.md). Even the Super Admin can't see patient data.

**Do we lose data if we don't renew?**
No. The hospital becomes read-only; data stays and can be downloaded. Renewing unlocks everything.

**We registered while plans were free. What happens when charging starts?**
You get e-mails first (usually 7 days' notice). Keep working as normal; when the date comes, the owner pays from **Subscription**. Nothing is deleted, and if you don't pay you simply go read-only after the grace days.

**"This e-mail already has a free workspace"**
Only one free workspace is allowed per owner e-mail. Sign in to the existing one, or use a different owner e-mail for a genuinely separate hospital.

**Can we use it on a phone or tablet?**
Yes, the screens adapt to small screens. Tables scroll sideways on phones.

**Can we change a bill after printing it?**
Not after finalising. Issue a refund or cancel the bill (with reason) and create a new one. This protects against fraud and keeps accounts correct.

**Why can't I edit a package price on the edit screen?**
Package prices change only through *Price history*, so every change has a date, reason and person.

**Why do some tests appear in a grey "in package" state when ordering?**
They are already inside a package you ticked; ordering them separately would charge twice.

**Can a hospital have more than one branch?**
Multi-branch is planned for the Enterprise plan; it is not available yet.

**Where do I change the hospital name/address printed on bills and lab reports?**
Administration → Settings.

**Can I export to Excel?**
Yes — Reports → choose a report → *Export CSV* (needs the *reports.export* permission). For everything at once, use Backups.

**We shared passwords/keys in a chat or e-mail. What now?**
Change them: the database password (at your host), `SUPERADMIN_PASSWORD` (log in and change it, or update `.env` and reseed), and generate a new `JWT_SECRET` (everyone will need to log in again).

Next: [13. Glossary →](13-glossary.md)
